# MACTN

This is the official implementation of the MACTN model.
